// 'use strict';

// const electron = require('electron');
// const app = electron.app;

// const path = electron.path;
// const url = electron.url;
// const BrowserWindow = electron.BrowserWindow;
// var fs = electron.fs;
// var ipc = electron.ipcMain;
// const Menu = electron.Menu;

// var menu = Menu.buildFromTemplate([{
// label: 'Electron',
// submenu:[
//     {
//         label: 'Prefs',
//         click: function(){
//             ipc.send('show-prefs');
//         }
//     }
// ]
// }]);
// Menu.setApplicationMenu(menu);

